package com.example.consumingwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumingWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
